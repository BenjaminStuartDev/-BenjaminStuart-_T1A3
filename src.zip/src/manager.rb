# frozen_string_literal: true

require_relative './staff'

# Top level documentation comment for 'class Staff'.
class Manager < Staff
end
