# frozen_string_literal: true

require './menuitem'

describe MenuItem do
  let(:menuitem) { MenuItem.new('meal1', 13.0, %w[ingredient1 ingredient2]) }

  it 'can be instantiated' do
    expect(menuitem).not_to be_nil
    expect(menuitem).to be_an_instance_of MenuItem
  end
end
